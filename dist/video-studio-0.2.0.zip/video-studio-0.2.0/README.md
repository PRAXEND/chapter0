# Video Studio

按用户选择的题材和风格制作视频，并把参考脚本、视频提炼成下次可调用的风格技能。

**本地开发版 0.2.0 · macOS / Codex · 依赖已安装且登录的 ChatCut**

## 组成

| 层 | 作用 |
|---|---|
| 本次制作要求 | 题材、目的、受众、语言、时长、画幅、声音、字幕 |
| 可选个人风格技能 | 从用户参考提炼的叙事、镜头、节奏、文字、图形与声音规则 |
| 通用工具技能 | 素材采集、ChatCut 编辑、声音字幕、完整验收与交付 |

通用层不预置机器人主题、男声、科技风、竖屏、90秒、快切或MG模板。个人风格库初始为空。选择风格后，素材采集同时考虑“内容相关”和“表现形式合适”；未指定风格时按本次需求创作，不自动保存为默认风格。

## 技能

- `video-project`：解析本期要求，选择并加载实际风格 SKILL.md，组织工具。
- `setup-video-studio`：检查本地依赖及 ChatCut 连接，保存明确偏好。
- `video-source-tools`：按题材与风格形成采集计划，核实和获取素材。
- `chatcut-edit-tools`：项目、导入、时间线、MG、转场的工具用法。
- `video-audio-tools`：配音、音乐、字幕与真实时序同步。
- `learn-video-style`：参考分析、风格技能保存、版本更新与复用。
- `video-quality-review`：独立完整验收与问题修复复查。
- `video-delivery-tools`：导出任务、文件与可编辑工程交付。

## 使用方式

> 用 Video Studio 做一个咖啡制作视频，横屏、三分钟，先让我选择表现风格。

> 把这个脚本和参考视频的风格保存为“我的过程解说”。下次我选择这个风格时，结合新的题材找素材和剪辑。

> 用“我的过程解说”做一期旅行视频，本期不要配音，保留现场声。

> 使用 $video-quality-review 完整验收这条视频，列出问题时间点；修复后再完整复查。

已给题材直接采用；未给题材询问或按明确委托选题。仅提供脚本时提炼叙事/语言，无法观察的画面、节奏、动画、声音维度保持未知。提供视频时分析连续片段与实际声音。规则保存有证据位置、检验方法和跨题材适配说明；工具不会把“保存成功”冒充“风格复现已通过”。

风格文件位于 `~/Library/Application Support/Video Studio/styles/<id>/<version>/`，含真正的 SKILL.md、style.json 和校验清单。由插件主动发现读取，下一次聊天可选择；不是自动注册到全局技能列表。升级插件不会覆盖个人库，发行包不包含用户参考和个人风格。每期固定风格版本及内容快照，本期覆盖不会修改库。

## 独立完整验收

检查整片与全部事件边界，并记录时间/帧号、实际证据、严重程度、修复与复查：

- 音画、对白/动作/拟音、解说与动画同步，以及累计漂移。
- 不同素材、字幕、MG、遮罩和运动主体之间的意外遮挡。
- 背景音乐的情绪节奏、音量、可懂度、ducking、循环接缝与淡入淡出。
- 所有硬切和转场的源余量、残帧、跳位、黑边及连续性。
- 字幕时间与进出动画、换句换行、闪现、拖尾、抖动和可读性。
- 闪帧、黑白帧、重复/丢帧、异常冻结、亮度跳变、图层开关及运动断点。
- 比例、尺寸、fps、清晰度、文字数字、裁切安全区、音质、首尾及最终文件完整性。

[完整验收技能](plugins/video-studio/skills/video-quality-review/SKILL.md)与[记录规范](plugins/video-studio/references/quality-review.md)区分自动检测线索、实际观看/听审通过和未验证。没有感知证据不能填通过，旧导出审核不能替代新导出审核；有意的风格效果按当前要求判断。

## 安装与验证

安装包：`dist/video-studio-0.2.0.zip`，校验文件同目录。解压后的根目录包含 marketplace 和 plugins：

```sh
shasum -a 256 -c video-studio-0.2.0.zip.sha256
unzip video-studio-0.2.0.zip
codex plugin marketplace add ./video-studio-0.2.0
```

在插件目录选择 Video Studio 本地来源安装，并在新聊天验证技能。安装缓存与市场源不是同一份文件；不要手工改缓存。插件目录与本地市场机制见 [OpenAI 官方文档](https://developers.openai.com/plugins/build/plugins)。

ChatCut 必须单独安装并认证。制作由 Codex 调用 ChatCut；本地脚本不自行联网调用生成服务。系统依赖为完整 Python 3.10+、FFmpeg/ffprobe，以及下载时需要的 Node 或 Deno 与 yt-dlp。`bootstrap` 仅安装独立 Python 下载依赖。

从源码根运行：

```sh
python3 plugins/video-studio/scripts/studio.py doctor
python3 plugins/video-studio/scripts/studio.py styles list
python3 -m unittest discover -s tests -v
python3 tools/package.py
```

doctor 本地成功不表示 ChatCut 已连接。使用宿主完整 Python；损坏的系统 Python 不用于验证。

## 数据与兼容

运行目录默认 ~/Movies/Video Studio；VIDEO_STUDIO_HOME 可指定状态根，VIDEO_STUDIO_FFMPEG_DIR 指定二进制目录。规格来自本期 brief；宽高为偶数正整数，fps/时长可配置，实际输出仍以 ChatCut 能力为准。默认6视频源/300秒是可调整的下载预算，不是风格。

0.1.x 的旧 creative/style 和固定规格不自动导入。旧 run 的 schema 1 留给原插件继续，新版 schema 2 不覆盖旧项目。用户明确的音色等偏好可按需迁移。本包不包含发布、定时监控或后台制片服务。

[命令与记录](plugins/video-studio/references/operations.md) · [风格规格](plugins/video-studio/references/style-format.md) · [可选诊断](plugins/video-studio/references/diagnostics.md) · [验证范围](VALIDATION.md)
